using UnityEngine;
using System;
using System.Collections.ObjectModel;
using LostPolygon.AndroidBluetoothMultiplayer;


public class BluetoothMultiplayerAPI : MultiplayerAPI{
	#region public class properties
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/// <summary>
	/// The duration of the discoverability.
	/// </summary>
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static int DiscoverabilityDuration = 120;
	#endregion

	#region protected instance fields
	protected NetworkPeerType? _previousPeerType = null;
	#endregion

//	#region public class event listeners: SERVER EVENTS
//	// AndroidBluetoothMultiplayer.ListeningStopped		---> OnServerStopped
//	// AndroidBluetoothMultiplayer.AdapterDisabled		---> OnServerStopped ???
//	
//	// AndroidBluetoothMultiplayer.ClientConnected		---> OnClientConnected
//	// AndroidBluetoothMultiplayer.ClientDisconnected	---> OnClientDisconnected
//	#endregion
//	
//	#region public class event listeners: CLIENT EVENTS
//	// AndroidBluetoothMultiplayer.ConnectedToServer	---> OnConnectedToServer
//	// AndroidBluetoothMultiplayer.DisconnectedToServer	---> OnDisconnectedFromServer
//	// AndroidBluetoothMultiplayer.AdapterDisabled		---> OnDisconnectedFromServer ???
//	#endregion

	#region public override properties
	public override int Connections{
		get{
			return Network.connections.Length;
		}
	}

	public override NetworkPlayer NetworkPlayer{
		get{
			return Network.player;
		}
	}

	public override float SendRate{
		get{
			return Network.sendRate;
		}
		set{
			Network.sendRate = value;
		}
	}
	#endregion

	#region public instance methods
	public override void Connect(string address, int port){
#if UNITY_ANDROID
		Action<BluetoothDevice> onConnectedToServer = null;
		Action<BluetoothDevice> onConnectedToServerFailed = null;

		onConnectedToServer = delegate(BluetoothDevice device){
			AndroidBluetoothMultiplayer.ConnectedToServer -= onConnectedToServer;
			AndroidBluetoothMultiplayer.ConnectionToServerFailed -= onConnectedToServerFailed;

			// Trying to negotiate a Unity networking connection, when Bluetooth client connected successfully
			// The IP for Network.Connect(), must always be 127.0.0.1
			Network.Connect("127.0.0.1", port);
		};

		onConnectedToServerFailed = delegate(BluetoothDevice device){
			AndroidBluetoothMultiplayer.ConnectedToServer -= onConnectedToServer;
			AndroidBluetoothMultiplayer.ConnectionToServerFailed -= onConnectedToServerFailed;
			this.RaiseOnServerConnectionError(NetworkConnectionError.ConnectionFailed);
		};


		AndroidBluetoothMultiplayer.ConnectedToServer += onConnectedToServer;
		AndroidBluetoothMultiplayer.ConnectionToServerFailed += onConnectedToServerFailed;
		AndroidBluetoothMultiplayer.Connect(address, (ushort)port);
#endif
	}

	public override bool Disconnect(){
#if UNITY_ANDROID
		return AndroidBluetoothMultiplayer.Stop();
#else
		return true;
#endif
	}

	public override void FindLanGames(){
#if UNITY_ANDROID
		if (AndroidBluetoothMultiplayer.GetIsBluetoothEnabled()){
			//---------------------------------------------------------------------------------------------------------
			// If Bluetooth is enabled, we can start the server immediately
			//---------------------------------------------------------------------------------------------------------
			this.DoFindLanGames();
		}else{
			//---------------------------------------------------------------------------------------------------------
			// If Bluetooth is disabled, we need to enable the bluetooth adapter before starting the server
			//---------------------------------------------------------------------------------------------------------
			Action adapterEnabledCallback = null;
			Action adapterEnableFailedCallback = null;
			
			adapterEnabledCallback = delegate(){
				AndroidBluetoothMultiplayer.AdapterEnabled -= adapterEnabledCallback;
				AndroidBluetoothMultiplayer.AdapterEnableFailed -= adapterEnableFailedCallback;
				this.DoFindLanGames();
			};
			
			adapterEnableFailedCallback = delegate(){
				AndroidBluetoothMultiplayer.AdapterEnabled -= adapterEnabledCallback;
				AndroidBluetoothMultiplayer.AdapterEnableFailed -= adapterEnableFailedCallback;
				this.RaiseOnLanGamesDiscoveryError(NetworkConnectionError.ConnectionFailed);
			};
			
			AndroidBluetoothMultiplayer.AdapterEnabled += adapterEnabledCallback;
			AndroidBluetoothMultiplayer.AdapterEnableFailed += adapterEnableFailedCallback;
			AndroidBluetoothMultiplayer.RequestEnableBluetooth();
		}
#endif
	}

	public override bool Initialize(string uuid){
#if UNITY_ANDROID
		return base.Initialize(uuid) && AndroidBluetoothMultiplayer.Initialize(uuid);
#else
		return base.Initialize(uuid);
#endif
	}


	public override NetworkState GetConnectionState(){
#if UNITY_ANDROID
		BluetoothMultiplayerMode mode = AndroidBluetoothMultiplayer.GetCurrentMode(); 

		if (mode == BluetoothMultiplayerMode.None){
			return NetworkState.Disconnected;
		}else if (mode == BluetoothMultiplayerMode.Client){
			return NetworkState.Client;
		}else{
			return NetworkState.Server;
		}
#else
		return NetworkState.Disconnected;
#endif
	}

	public override void StartServer(int connections, int listenPort, bool useNat){
#if UNITY_ANDROID
		if (AndroidBluetoothMultiplayer.GetIsBluetoothEnabled()){
			//---------------------------------------------------------------------------------------------------------
			// If Bluetooth is enabled, we can start the server immediately
			//---------------------------------------------------------------------------------------------------------
			this.DoStartServer(connections, listenPort, useNat);
		}else{
			//---------------------------------------------------------------------------------------------------------
			// If Bluetooth is disabled, we need to enable the bluetooth adapter before starting the server
			//---------------------------------------------------------------------------------------------------------
			Action adapterEnabledCallback = null;
			Action adapterEnableFailedCallback = null;

			adapterEnabledCallback = delegate(){
				AndroidBluetoothMultiplayer.AdapterEnabled -= adapterEnabledCallback;
				AndroidBluetoothMultiplayer.AdapterEnableFailed -= adapterEnableFailedCallback;
				this.DoStartServer(connections, listenPort, useNat);
			};

			adapterEnableFailedCallback = delegate(){
				AndroidBluetoothMultiplayer.AdapterEnabled -= adapterEnabledCallback;
				AndroidBluetoothMultiplayer.AdapterEnableFailed -= adapterEnableFailedCallback;
				this.RaiseOnServerInitializationError(NetworkConnectionError.ConnectionFailed);
			};

			AndroidBluetoothMultiplayer.AdapterEnabled += adapterEnabledCallback;
			AndroidBluetoothMultiplayer.AdapterEnableFailed += adapterEnableFailedCallback;
			AndroidBluetoothMultiplayer.RequestEnableBluetooth();
		}
#endif
	}

	public override bool StopServer (){
#if UNITY_ANDROID
		return AndroidBluetoothMultiplayer.Stop();
#else
		return true;
#endif
	}
	#endregion

	#region protected override methods
	protected override bool SendNetworkMessage(byte[] bytes){
		this.GetComponent<NetworkView>().RPC("Bluetooth", RPCMode.Others, bytes);
		return true;
	}
	#endregion

	#region protected instance methods
	protected virtual void DoFindLanGames(){
#if UNITY_ANDROID
		Action<BluetoothDevice> onDevicePicked = null;
		onDevicePicked = delegate(BluetoothDevice device){
			AndroidBluetoothMultiplayer.DevicePicked -= onDevicePicked;
			
			if (device != null){
				this.RaiseOnOnLanGamesDiscovered(new ReadOnlyCollection<string>(new string[]{device.Address}));
			}else{
				this.RaiseOnOnLanGamesDiscovered(new ReadOnlyCollection<string>(new string[]{}));
			}
		};
		
		AndroidBluetoothMultiplayer.DevicePicked += onDevicePicked;
		Network.Disconnect();
		AndroidBluetoothMultiplayer.ShowDeviceList();
#endif
	}

	protected virtual void DoStartServer(int connections, int listenPort, bool useNat){
#if UNITY_ANDROID
		Action onBluetoothListeningStarted = null;
		Action onBluetoothListeningStopped = null;

		onBluetoothListeningStarted = delegate() {
			AndroidBluetoothMultiplayer.ListeningStarted -= onBluetoothListeningStarted;
			AndroidBluetoothMultiplayer.ListeningStopped -= onBluetoothListeningStopped;
			Action<int> onBluetoothDiscoverabilityEnabled = null;
			Action onBluetoothDiscoverabilityEnableFailed = null;

			onBluetoothDiscoverabilityEnabled = delegate(int discoverabilityDuration) {
				AndroidBluetoothMultiplayer.DiscoverabilityEnabled -= onBluetoothDiscoverabilityEnabled;
				AndroidBluetoothMultiplayer.DiscoverabilityEnableFailed -= onBluetoothDiscoverabilityEnableFailed;
			};

			onBluetoothDiscoverabilityEnableFailed = delegate() {
				AndroidBluetoothMultiplayer.DiscoverabilityEnabled -= onBluetoothDiscoverabilityEnabled;
				AndroidBluetoothMultiplayer.DiscoverabilityEnableFailed -= onBluetoothDiscoverabilityEnableFailed;
				this.RaiseOnServerInitializationError(NetworkConnectionError.ConnectionFailed);
			};

			Network.InitializeServer(connections, listenPort, false);
		};

		onBluetoothListeningStopped = delegate() {
			AndroidBluetoothMultiplayer.ListeningStarted -= onBluetoothListeningStarted;
			AndroidBluetoothMultiplayer.ListeningStopped -= onBluetoothListeningStopped;
			AndroidBluetoothMultiplayer.Stop();
			this.RaiseOnServerInitializationError(NetworkConnectionError.ConnectionFailed);
		};

		AndroidBluetoothMultiplayer.RequestEnableDiscoverability(BluetoothMultiplayerAPI.DiscoverabilityDuration);
		Network.Disconnect();
		AndroidBluetoothMultiplayer.ListeningStarted += onBluetoothListeningStarted;
		AndroidBluetoothMultiplayer.ListeningStopped += onBluetoothListeningStopped;
		AndroidBluetoothMultiplayer.StartServer((ushort)listenPort);
#endif
	}

	[RPC]
	public virtual void Bluetooth(byte[] bytes, NetworkMessageInfo msgInfo){
		this.RaiseOnMessageReceived(bytes, msgInfo);
	}
	#endregion

	#region protected MonoBehaviour methods
	protected virtual void OnConnectedToServer(){
		this.RaiseOnServerConnectionSuccess();
	}
	
	protected virtual void OnDisconnectedFromServer(NetworkDisconnection info){
#if UNITY_ANDROID
		AndroidBluetoothMultiplayer.Stop();
#endif
		this.RaiseOnDisconnection(info);
	}

	protected virtual void OnFailedToConnect(NetworkConnectionError error){
#if UNITY_ANDROID
		AndroidBluetoothMultiplayer.Stop();
#endif
		this.RaiseOnServerConnectionError(error);
	}

	protected virtual void OnPlayerConnected(NetworkPlayer player){
		this.RaiseOnPlayerConnectedToServer(player);
	}

	protected virtual void OnPlayerDisconnected(NetworkPlayer player){
		Network.RemoveRPCs(player);
		Network.DestroyPlayerObjects(player);
		this.RaiseOnPlayerDisconnectedFromServer(player);
	}

	protected virtual void OnServerInitialized(){
		this.RaiseOnServerStarted();
	}

	protected virtual void Update(){
		if(
			Network.peerType == NetworkPeerType.Disconnected &&
			this._previousPeerType != null &&
			this._previousPeerType != NetworkPeerType.Disconnected
		){
			this.RaiseOnServerStopped();
		}

		this._previousPeerType = Network.peerType;
	}
	#endregion
}
